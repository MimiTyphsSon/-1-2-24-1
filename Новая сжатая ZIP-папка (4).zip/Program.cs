﻿using System;
using System.Data;
using Npgsql;

class Program
{
    static void Main()
    {
        string connectionString = "Host=wotacoma.ru;Port=5090;Username=students;Password=asd123qwe4ewq321dsa;Database=9/3-RPO-24/1";
        DataTable table = new DataTable();

        using (var conn = new NpgsqlConnection(connectionString))
        {
            conn.Open();
            string selectSql = "SELECT * FROM \"students_lesson13\" LIMIT 10";
            using (var adapter = new NpgsqlDataAdapter(selectSql, conn))
            {
                adapter.Fill(table);

                adapter.InsertCommand = new NpgsqlCommand(
                    "INSERT INTO \"students_lesson13\" (nickname, first_name, last_name) " +
                    "VALUES (@nickname, @first_name, @last_name) RETURNING id", conn);

                adapter.InsertCommand.Parameters.Add("@nickname", NpgsqlTypes.NpgsqlDbType.Text, 0, "nickname");
                adapter.InsertCommand.Parameters.Add("@first_name", NpgsqlTypes.NpgsqlDbType.Text, 0, "first_name");
                adapter.InsertCommand.Parameters.Add("@last_name", NpgsqlTypes.NpgsqlDbType.Text, 0, "last_name");

                NpgsqlParameter idParam = adapter.InsertCommand.Parameters.Add("@id", NpgsqlTypes.NpgsqlDbType.Integer, 0, "id");
                idParam.Direction = ParameterDirection.Output;
                adapter.InsertCommand.UpdatedRowSource = UpdateRowSource.OutputParameters;

                adapter.UpdateCommand = new NpgsqlCommand(
                    "UPDATE \"students_lesson13\" SET nickname = @nickname, first_name = @first_name, last_name = @last_name " +
                    "WHERE id = @id", conn);

                adapter.UpdateCommand.Parameters.Add("@nickname", NpgsqlTypes.NpgsqlDbType.Text, 0, "nickname");
                adapter.UpdateCommand.Parameters.Add("@first_name", NpgsqlTypes.NpgsqlDbType.Text, 0, "first_name");
                adapter.UpdateCommand.Parameters.Add("@last_name", NpgsqlTypes.NpgsqlDbType.Text, 0, "last_name");
                adapter.UpdateCommand.Parameters.Add("@id", NpgsqlTypes.NpgsqlDbType.Integer, 0, "id");

                adapter.DeleteCommand = new NpgsqlCommand(
                    "DELETE FROM \"students_lesson13\" WHERE id = @id", conn);

                adapter.DeleteCommand.Parameters.Add("@id", NpgsqlTypes.NpgsqlDbType.Integer, 0, "id");

                Console.WriteLine("=== 1. Исходное состояние ===");
                PrintTable(table);

                DataRow modifiedRow = table.Rows[0];
                modifiedRow["first_name"] = "ИЗМЕНЕНО";

                DataRow newRow = table.NewRow();
                newRow["nickname"] = "newbie";
                newRow["first_name"] = "Петр";
                newRow["last_name"] = "Петров";
                table.Rows.Add(newRow);

                DataRow deletedRow = table.Rows[1];
                deletedRow.Delete();

                Console.WriteLine("\n=== 2. Состояние после изменений (до Update) ===");
                PrintTable(table);

                try
                {
                    int rowsAffected = adapter.Update(table);
                    Console.WriteLine($"\n=== 3. Update выполнен. Затронуто строк: {rowsAffected} ===");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"\n=== ОШИБКА СОХРАНЕНИЯ: {ex.Message} ===");
                }

                Console.WriteLine("\n=== 4. Состояние после Update ===");
                PrintTable(table);
            }
        }

        Console.WriteLine("\nНажмите любую клавишу для выхода...");
        Console.ReadKey();
    }

    static void PrintTable(DataTable table)
    {
        Console.WriteLine($"{"ID",-6} | {"Никнейм",-15} | {"Имя",-15} | {"Фамилия",-15} | {"Состояние",-12}");
        Console.WriteLine(new string('-', 85));

        foreach (DataRow row in table.Rows)
        {
            if (row.RowState == DataRowState.Deleted)
            {
                string id = row["id", DataRowVersion.Original].ToString();
                string nick = row["nickname", DataRowVersion.Original].ToString();
                string first = row["first_name", DataRowVersion.Original].ToString();
                string last = row["last_name", DataRowVersion.Original].ToString();
                Console.WriteLine($"{id,-6} | {nick,-15} | {first,-15} | {last,-15} | {row.RowState,-12} <-- УДАЛЕНА");
            }
            else
            {
                string id = row["id"].ToString();
                string nick = row["nickname"] == DBNull.Value ? "NULL" : row["nickname"].ToString();
                string first = row["first_name"] == DBNull.Value ? "NULL" : row["first_name"].ToString();
                string last = row["last_name"] == DBNull.Value ? "NULL" : row["last_name"].ToString();
                Console.WriteLine($"{id,-6} | {nick,-15} | {first,-15} | {last,-15} | {row.RowState,-12}");
            }
        }
        Console.WriteLine($"Всего строк в таблице: {table.Rows.Count}");
    }
}