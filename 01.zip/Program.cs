﻿using System;
using System.Data;
using Npgsql;

class Program
{
    static void Main()
    {
        string connectionString = "Host=wotacoma.ru;Port=5090;Username=students;Password=asd123qwe4ewq321dsa;Database=9/3-RPO-24/1";

        DataTable table = new DataTable();

        using (var conn = new NpgsqlConnection(connectionString))
        {
            conn.Open();
            string sql = "SELECT * FROM \"students_lesson13\" LIMIT 10";
            using (var adapter = new NpgsqlDataAdapter(sql, conn))
            {
                adapter.Fill(table);
            }
        }

        Console.WriteLine("==================================================");
        Console.WriteLine("=== ТАБЛИЦА ДО ИЗМЕНЕНИЙ ===");
        Console.WriteLine("==================================================");
        PrintFullTable(table);

        Console.WriteLine("\n>>> Выполняем изменения (Modify, Add, Delete)...");

        DataRow modifiedRow = table.Rows[0];
        modifiedRow["first_name"] = modifiedRow["first_name"].ToString() + " (ИЗМЕНЕН)";

        DataRow newRow = table.NewRow();
        newRow["id"] = 999;
        newRow["nickname"] = "newbie";
        newRow["first_name"] = "Петр";
        newRow["last_name"] = "Петров";
        table.Rows.Add(newRow);

        DataRow deletedRow = table.Rows[1];
        deletedRow.Delete();

        Console.WriteLine("\n==================================================");
        Console.WriteLine("=== ТАБЛИЦА ПОСЛЕ ОПЕРАЦИЙ (ДО AcceptChanges) ===");
        Console.WriteLine("==================================================");
        PrintFullTable(table);

        Console.WriteLine("\n>>> Вызываем AcceptChanges()...");
        table.AcceptChanges();

        Console.WriteLine("\n==================================================");
        Console.WriteLine("=== ТАБЛИЦА ПОСЛЕ AcceptChanges ===");
        Console.WriteLine("==================================================");
        PrintFullTable(table);

        Console.WriteLine("\nНажмите любую клавишу для выхода...");
        Console.ReadKey();
    }

    static void PrintFullTable(DataTable table)
    {
        foreach (DataColumn column in table.Columns)
        {
            Console.Write($"{column.ColumnName,-15} | ");
        }
        Console.WriteLine();
        Console.WriteLine(new string('-', 80));

        foreach (DataRow row in table.Rows)
        {
            if (row.RowState == DataRowState.Deleted)
            {
                foreach (DataColumn column in table.Columns)
                {
                    Console.Write($"{row[column, DataRowVersion.Original],-15} | ");
                }
                Console.WriteLine(" <-- УДАЛЕНА");
            }
            else
            {
                foreach (DataColumn column in table.Columns)
                {
                    string value = row[column] == DBNull.Value ? "NULL" : row[column].ToString();
                    Console.Write($"{value,-15} | ");
                }
                Console.WriteLine();
            }
        }
    }
}